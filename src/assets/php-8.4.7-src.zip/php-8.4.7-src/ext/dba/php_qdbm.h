#ifndef PHP_QDBM_H
#define PHP_QDBM_H

#ifdef DBA_QDBM

#include "php_dba.h"

DBA_FUNCS(qdbm);

#endif

#endif
